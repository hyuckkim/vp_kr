UPDATE Language_ko_KR
SET Text = '모든 궁기병 계열 유닛이 두 번 공격할 수 있습니다. [ICON_CITY_STATE]도시 국가가 바치는 공물의 산출량이 [COLOR_POSITIVE_TEXT]50%[ENDCOLOR] 증가합니다.'
WHERE Tag = 'TXT_KEY_TRAIT_TERROR';

UPDATE Language_ko_KR
SET Text = '[ICON_RANGE_STRENGTH] 전투력 +1.'
WHERE Tag = 'TXT_KEY_PROMOTION_MONGOL_TERROR_HELP';